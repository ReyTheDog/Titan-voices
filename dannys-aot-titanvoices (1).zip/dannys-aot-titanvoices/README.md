# Danny's AoT - Titan Voices

Bridges **Simple Voice Chat** and **Danny's AoT**: while you are inside a shifter titan, your voice changes.

| Titan | Voice |
|---|---|
| Beast | much louder, ~3x farther, deeper pitch, light echo |
| Warhammer | much louder, ~3x farther, normal pitch, strong reverb |
| Cart | rough, distorted and lower but still understandable |
| Attack, Armored, Colossal, Female, Jaw, Ogre | muted |
| Any titan, while peeking out of the nape | normal voice again |

## Mouth movement
While a Beast or Warhammer shifter speaks, the titan's `mouth` / `jaw` bone opens with the loudness of the voice; the Cart nods its head. Titans that cannot speak never move their mouth. This needs the mod on the **clients** too (it is a client-side hook into GeckoLib 4, no GeckoLib compile dependency). Turn it off with `mouthAnimation=false`.

## Install
Put it in the `mods` folder of the **server/host** (voice effects) and of every **player** (mouth movement), together with Fabric API, Simple Voice Chat and Danny's AoT. Simple Voice Chat does not run in pure singleplayer, so test on a LAN world or a server.

## Config
`config/dannys-aot-titanvoices.properties` (created on first start): pitch, gain, bass, distortion, ringMod, reverb and distance per titan, `muteOtherTitans`, `peekRestoresVoice`, `whisperFactor`, `maxDistance`, `debug`.

## How it works
Every microphone packet of a player in a titan is cancelled, decoded, run through pitch shift / distortion / bass / soft-clipped gain, re-encoded and re-sent from the player's position with a larger range. Titan state is read from Danny's AoT by reflection on the main thread (every 5 ticks).

## Limits
- Players in a voice group lose group delivery while in a titan (the effect voice is proximity only).
- The server's own maximum voice distance settings may cap how far the voice really carries.
- Written against the Simple Voice Chat API 2.5 line; not tested in-game yet.
