package dev.titanvoice;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server to client: how loud the shifter inside a titan is speaking right now (level 0..100). */
public record MouthPayload(int entityId, int kind, int level) implements CustomPayload {
    public static final int BEAST = 1;
    public static final int WARHAMMER = 2;
    public static final int CART = 3;

    public static final CustomPayload.Id<MouthPayload> ID =
            new CustomPayload.Id<>(Identifier.of("dannys-aot-titanvoices", "mouth"));
    public static final PacketCodec<RegistryByteBuf, MouthPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, MouthPayload::entityId,
            PacketCodecs.VAR_INT, MouthPayload::kind,
            PacketCodecs.VAR_INT, MouthPayload::level,
            MouthPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
