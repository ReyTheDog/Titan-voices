package dev.titanvoice;

import dev.titanvoice.core.TitanKind;
import dev.titanvoice.core.VoiceConfig;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Sends the speaking loudness to the players who can see the titan, so its mouth (or the Cart's head) moves. */
final class MouthSync {
    private MouthSync() {}

    static void tick(MinecraftServer server) {
        if (server.getTicks() % 2 != 0 || MouthLevels.LEVELS.isEmpty()) return;
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, MouthLevels.Entry>> it = MouthLevels.LEVELS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, MouthLevels.Entry> me = it.next();
            MouthLevels.Entry e = me.getValue();
            TitanStates.State st = TitanStates.get(me.getKey());
            boolean silent = e.level <= 0f || now - e.at > 150L;
            if (st == null || st.titan == null || st.titan.isRemoved() || !VoiceConfig.mouthAnimation) {
                it.remove();
                continue;
            }
            if (silent && e.sentSilence) {
                if (now - e.at > 5000L) it.remove();
                continue;
            }
            int kind = kindId(st.kind);
            if (kind == 0) {
                it.remove();
                continue;
            }
            int level = silent ? 0 : Math.round(Math.max(0f, Math.min(1f, e.level)) * 100f);
            send(server, st.titan, me.getKey(), new MouthPayload(st.titan.getId(), kind, level));
            if (silent) e.sentSilence = true;
        }
    }

    private static int kindId(TitanKind k) {
        switch (k) {
            case BEAST: return MouthPayload.BEAST;
            case WARHAMMER: return MouthPayload.WARHAMMER;
            case CART: return MouthPayload.CART;
            default: return 0;
        }
    }

    private static void send(MinecraftServer server, Entity titan, UUID speaker, MouthPayload p) {
        Set<ServerPlayerEntity> to = new HashSet<>(PlayerLookup.tracking(titan));
        ServerPlayerEntity self = server.getPlayerManager().getPlayer(speaker);
        if (self != null) to.add(self);
        for (ServerPlayerEntity r : to) {
            if (ServerPlayNetworking.canSend(r, MouthPayload.ID)) ServerPlayNetworking.send(r, p);
        }
    }
}
