package dev.titanvoice.mixin;

import dev.titanvoice.client.MouthApplier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Runs after GeckoLib has animated an entity, so the titan's jaw / head can follow the shifter's voice. */
@Pseudo
@Mixin(targets = "software.bernie.geckolib.model.GeoModel", remap = false)
public abstract class GeoModelMixin {
    @Inject(
            method = "handleAnimations(Lsoftware/bernie/geckolib/animatable/GeoAnimatable;JLsoftware/bernie/geckolib/animation/AnimationState;F)V",
            at = @At("RETURN"),
            remap = false,
            require = 0)
    private void titanvoices$mouth(@Coerce Object animatable, long instanceId, @Coerce Object state, float partialTick, CallbackInfo ci) {
        MouthApplier.apply(this, animatable);
    }
}
