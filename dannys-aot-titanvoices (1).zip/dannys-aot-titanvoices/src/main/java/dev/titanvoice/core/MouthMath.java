package dev.titanvoice.core;

/** Turns a voice frame into a 0..1 "how open is the mouth" value. */
public final class MouthMath {
    private MouthMath() {}

    public static float level(short[] pcm) {
        if (pcm == null || pcm.length == 0) return 0f;
        double sum = 0;
        for (short s : pcm) {
            double v = s / 32768.0;
            sum += v * v;
        }
        double rms = Math.sqrt(sum / pcm.length);
        double l = Math.pow(rms / 0.10, 0.6);
        return (float) Math.max(0.0, Math.min(1.0, l));
    }

    /** Exponential smoothing step: fast attack, slower release. */
    public static float smooth(float cur, float target, float dtSeconds) {
        float tau = target > cur ? 0.03f : 0.09f;
        float k = 1f - (float) Math.exp(-Math.max(0f, dtSeconds) / tau);
        return cur + (target - cur) * k;
    }
}
