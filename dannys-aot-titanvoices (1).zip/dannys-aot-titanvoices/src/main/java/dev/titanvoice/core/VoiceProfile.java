package dev.titanvoice.core;

/** What a titan's voice sounds like. */
public final class VoiceProfile {
    public final String name;
    /** 1 = normal pitch, below 1 = deeper. */
    public final float pitch;
    /** Loudness multiplier (soft-clipped, so it gets louder without harsh clipping). */
    public final float gain;
    /** 0..1: extra low frequencies, makes the voice bigger. */
    public final float bass;
    /** 0..1: how distorted (0 = clean). */
    public final float distortion;
    /** How many times farther than normal voice chat the voice carries. */
    public final float distance;
    /** 0..1: robotic ring modulation (makes the voice unrecognisable). */
    public final float ringMod;
    /** 0..1: reverb and echo amount. */
    public final float reverb;

    public VoiceProfile(String name, float pitch, float gain, float bass, float distortion, float distance, float ringMod, float reverb) {
        this.name = name;
        this.pitch = pitch;
        this.gain = gain;
        this.bass = bass;
        this.distortion = distortion;
        this.distance = distance;
        this.ringMod = ringMod;
        this.reverb = reverb;
    }

    public boolean needsPitchShift() {
        return Math.abs(pitch - 1f) > 0.005f;
    }
}
