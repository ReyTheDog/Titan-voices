package dev.titanvoice.core;

/** Mono room reverb (4 combs + 2 all-passes) plus a distinct echo repeat. {@code wet} 0..1. */
public final class Reverb {
    private static final int[] COMB = {1215, 1293, 1391, 1477};
    private static final int[] ALL = {556, 441};
    private static final int ECHO = 8640; // 180 ms

    private final float[][] combBuf = new float[4][];
    private final int[] combPos = new int[4];
    private final float[] combLp = new float[4];
    private final float[][] allBuf = new float[2][];
    private final int[] allPos = new int[2];
    private final float[] echoBuf = new float[ECHO];
    private int echoPos = 0;
    private final float wet, fb, echoFb;

    public Reverb(float wet) {
        this.wet = Math.max(0f, Math.min(1f, wet));
        this.fb = 0.80f + 0.11f * this.wet;
        this.echoFb = 0.25f + 0.3f * this.wet;
        for (int i = 0; i < 4; i++) combBuf[i] = new float[COMB[i]];
        for (int i = 0; i < 2; i++) allBuf[i] = new float[ALL[i]];
    }

    /** How many 20 ms frames the tail keeps ringing after the speaker stops. */
    public int tailFrames() {
        return (int) (30 + 60 * wet);
    }

    public float process(float x) {
        float in = x * 0.25f;
        float room = 0f;
        for (int i = 0; i < 4; i++) {
            float o = combBuf[i][combPos[i]];
            combLp[i] += 0.7f * (o - combLp[i]);
            combBuf[i][combPos[i]] = in + combLp[i] * fb;
            if (++combPos[i] >= COMB[i]) combPos[i] = 0;
            room += o;
        }
        for (int i = 0; i < 2; i++) {
            float b = allBuf[i][allPos[i]];
            float v = room - 0.5f * b;
            allBuf[i][allPos[i]] = v;
            room = b + 0.5f * v;
            if (++allPos[i] >= ALL[i]) allPos[i] = 0;
        }
        float e = echoBuf[echoPos];
        echoBuf[echoPos] = x + e * echoFb;
        if (++echoPos >= ECHO) echoPos = 0;
        return x * (1f - 0.25f * wet) + wet * (room * 1.4f + e * 0.6f);
    }

    public void reset() {
        for (float[] b : combBuf) java.util.Arrays.fill(b, 0f);
        for (float[] b : allBuf) java.util.Arrays.fill(b, 0f);
        java.util.Arrays.fill(echoBuf, 0f);
        java.util.Arrays.fill(combLp, 0f);
    }
}
