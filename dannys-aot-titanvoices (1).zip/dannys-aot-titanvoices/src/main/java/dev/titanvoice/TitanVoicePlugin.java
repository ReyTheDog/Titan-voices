package dev.titanvoice;

import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatServerApi;
import de.maxhenkel.voicechat.api.audiochannel.EntityAudioChannel;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MicrophonePacketEvent;
import de.maxhenkel.voicechat.api.events.VoicechatServerStartedEvent;
import de.maxhenkel.voicechat.api.opus.OpusDecoder;
import de.maxhenkel.voicechat.api.opus.OpusEncoder;
import dev.titanvoice.core.EffectChain;
import dev.titanvoice.core.VoiceConfig;
import dev.titanvoice.core.VoiceDecision;
import dev.titanvoice.core.VoiceProfile;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The bridge to Simple Voice Chat. Every microphone packet of a player in a titan is cancelled and, when it
 * should be heard, decoded, run through the titan's effects, re-encoded and sent again from the player.
 */
public class TitanVoicePlugin implements VoicechatPlugin {
    private static final long IDLE_MS = 30_000L;

    private static final Map<UUID, Speaker> SPEAKERS = new ConcurrentHashMap<>();
    private static volatile VoicechatServerApi api;
    private static volatile long lastPrune = 0L;

    private static final class Speaker {
        final OpusDecoder decoder;
        final OpusEncoder encoder;
        final EntityAudioChannel channel;
        VoiceProfile profile;
        EffectChain chain;
        boolean whisper;
        boolean active;
        float distance = -1f;
        volatile long lastUsed;

        Speaker(OpusDecoder d, OpusEncoder e, EntityAudioChannel c) {
            decoder = d;
            encoder = e;
            channel = c;
        }

        void close() {
            try { decoder.close(); } catch (Throwable ignored) { }
            try { encoder.close(); } catch (Throwable ignored) { }
        }
    }

    @Override
    public String getPluginId() {
        return "dannys-aot-titanvoices";
    }

    @Override
    public void initialize(VoicechatApi voicechatApi) {
        TitanVoiceMod.LOGGER.info("Connected to Simple Voice Chat");
    }

    @Override
    public void registerEvents(EventRegistration registration) {
        registration.registerEvent(VoicechatServerStartedEvent.class, e -> api = e.getVoicechat());
        registration.registerEvent(MicrophonePacketEvent.class, TitanVoicePlugin::onMic);
    }

    static void forget(UUID id) {
        Speaker s = SPEAKERS.remove(id);
        if (s != null) s.close();
    }

    private static void onMic(MicrophonePacketEvent event) {
        VoicechatServerApi server = api;
        if (server == null || !VoiceConfig.enabled) return;
        VoicechatConnection con = event.getSenderConnection();
        if (con == null || con.getPlayer() == null) return;
        UUID id = con.getPlayer().getUuid();

        TitanStates.State state = TitanStates.get(id);
        VoiceDecision.Result r = VoiceDecision.decide(state == null ? null : state.kind, state != null && state.peeking);
        byte[] data = event.getPacket().getOpusEncodedData();
        boolean end = data == null || data.length == 0;

        try {
            switch (r.action) {
                case PASS: {
                    Speaker s = SPEAKERS.get(id);
                    if (s != null && s.active) finish(s);
                    prune();
                    return;
                }
                case MUTE: {
                    event.cancel();
                    return;
                }
                default: {
                    event.cancel();
                    Speaker s = speaker(server, id, event, con);
                    if (s == null) return;
                    s.lastUsed = System.currentTimeMillis();
                    if (end) {
                        finish(s);
                        return;
                    }
                    boolean whisper = event.getPacket().isWhispering();
                    if (s.profile != r.profile) {
                        s.profile = r.profile;
                        s.chain = new EffectChain(r.profile);
                        s.distance = -1f;
                        if (VoiceConfig.debug) TitanVoiceMod.LOGGER.info("{} speaks as {}", id, r.profile.name);
                    }
                    if (s.distance < 0f || s.whisper != whisper) {
                        s.whisper = whisper;
                        float base = (float) server.getBroadcastRange();
                        float d = base * r.profile.distance * (whisper ? VoiceConfig.whisperFactor : 1f);
                        s.distance = Math.min(VoiceConfig.maxDistance, Math.max(1f, d));
                        s.channel.setDistance(s.distance);
                        s.channel.setWhispering(false);
                    }
                    short[] pcm = s.decoder.decode(data);
                    s.active = true;
                    s.channel.send(s.encoder.encode(s.chain.process(pcm)));
                    prune();
                }
            }
        } catch (Throwable t) {
            TitanVoiceMod.LOGGER.warn("Voice processing failed for {}: {}", id, t.toString());
        }
    }

    private static Speaker speaker(VoicechatServerApi server, UUID id, MicrophonePacketEvent event, VoicechatConnection con) {
        Speaker s = SPEAKERS.get(id);
        if (s != null) return s;
        EntityAudioChannel ch = server.createEntityAudioChannel(UUID.randomUUID(), con.getPlayer());
        if (ch == null) return null;
        ch.setFilter(p -> !p.getUuid().equals(id));
        s = new Speaker(server.createDecoder(), server.createEncoder(), ch);
        SPEAKERS.put(id, s);
        return s;
    }

    private static void finish(Speaker s) {
        s.active = false;
        try { s.channel.flush(); } catch (Throwable ignored) { }
        try { s.decoder.resetState(); } catch (Throwable ignored) { }
        try { s.encoder.resetState(); } catch (Throwable ignored) { }
        if (s.chain != null) s.chain.reset();
    }

    private static void prune() {
        long now = System.currentTimeMillis();
        if (now - lastPrune < 10_000L) return;
        lastPrune = now;
        for (Map.Entry<UUID, Speaker> e : SPEAKERS.entrySet()) {
            if (now - e.getValue().lastUsed > IDLE_MS) {
                Speaker s = SPEAKERS.remove(e.getKey());
                if (s != null) s.close();
            }
        }
    }
}
