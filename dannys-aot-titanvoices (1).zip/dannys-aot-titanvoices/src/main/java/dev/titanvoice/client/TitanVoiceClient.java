package dev.titanvoice.client;

import dev.titanvoice.MouthPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

public class TitanVoiceClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(MouthPayload.ID,
                (payload, context) -> MouthStates.update(payload.entityId(), payload.kind(), payload.level() / 100f));
    }
}
