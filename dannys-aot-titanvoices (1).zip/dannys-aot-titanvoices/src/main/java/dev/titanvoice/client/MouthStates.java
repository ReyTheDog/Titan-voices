package dev.titanvoice.client;

import dev.titanvoice.core.MouthMath;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Client side: how open each speaking titan's mouth is, smoothed per frame. */
public final class MouthStates {
    private MouthStates() {}

    public static final class State {
        public int kind;
        float target;
        float cur;
        long lastPacket;
        long lastUpdate;
    }

    private static final Map<Integer, State> STATES = new ConcurrentHashMap<>();

    static void update(int entityId, int kind, float level) {
        long now = System.nanoTime();
        State s = STATES.computeIfAbsent(entityId, k -> {
            State n = new State();
            n.lastUpdate = now;
            return n;
        });
        s.kind = kind;
        s.target = level;
        s.lastPacket = now;
    }

    /** Current smoothed level 0..1, or -1 when this entity is not speaking. */
    public static float level(int entityId, int[] kindOut) {
        if (STATES.isEmpty()) return -1f;
        State s = STATES.get(entityId);
        if (s == null) return -1f;
        long now = System.nanoTime();
        float target = (now - s.lastPacket) > 300_000_000L ? 0f : s.target;
        float dt = (now - s.lastUpdate) / 1e9f;
        if (dt > 0f) {
            s.cur = MouthMath.smooth(s.cur, target, Math.min(dt, 0.1f));
            s.lastUpdate = now;
        }
        kindOut[0] = s.kind;
        if (s.cur < 0.005f && target == 0f && (now - s.lastPacket) > 2_000_000_000L) {
            STATES.remove(entityId);
            return -1f;
        }
        return s.cur;
    }

    static void prune() {
        long now = System.nanoTime();
        Iterator<Map.Entry<Integer, State>> it = STATES.entrySet().iterator();
        while (it.hasNext()) if (now - it.next().getValue().lastPacket > 60_000_000_000L) it.remove();
    }
}
