package dev.titanvoice.client;

import dev.titanvoice.MouthPayload;
import dev.titanvoice.TitanVoiceMod;
import net.minecraft.entity.Entity;

import java.lang.reflect.Method;
import java.util.Optional;
import java.util.WeakHashMap;

/**
 * Called right after GeckoLib has animated a titan. Adds a small extra rotation to the Beast's "mouth" bone, the
 * Warhammer's "jaw" bone or the Cart's "head" bone. GeckoLib is reached by reflection so it is not needed at
 * compile time.
 */
public final class MouthApplier {
    private MouthApplier() {}

    private static final float BEAST_DEG = 22f;
    private static final float WARHAMMER_DEG = 24f;
    private static final float CART_NOD_DEG = 6f;

    private static boolean failed = false;
    private static Method getBone, getRotX, setRotX;
    private static final WeakHashMap<Object, float[]> LEDGER = new WeakHashMap<>();
    private static final int[] KIND = new int[1];
    private static long lastPrune = 0;

    public static void apply(Object model, Object animatable) {
        if (failed || !(animatable instanceof Entity)) return;
        float level = MouthStates.level(((Entity) animatable).getId(), KIND);
        if (level < 0f) return;
        String bone;
        float deg;
        switch (KIND[0]) {
            case MouthPayload.BEAST: bone = "mouth"; deg = BEAST_DEG; break;
            case MouthPayload.WARHAMMER: bone = "jaw"; deg = WARHAMMER_DEG; break;
            case MouthPayload.CART: bone = "head"; deg = CART_NOD_DEG; break;
            default: return;
        }
        try {
            if (getBone == null) {
                getBone = model.getClass().getMethod("getBone", String.class);
            }
            Object opt = getBone.invoke(model, bone);
            if (!(opt instanceof Optional) || ((Optional<?>) opt).isEmpty()) return;
            Object b = ((Optional<?>) opt).get();
            if (getRotX == null) {
                getRotX = b.getClass().getMethod("getRotX");
                setRotX = b.getClass().getMethod("setRotX", float.class);
            }
            float cur = (Float) getRotX.invoke(b);
            float[] last = LEDGER.get(b);
            float base = (last != null && cur == last[0]) ? cur - last[1] : cur;
            // GeckoLib stores animation X rotation negated: positive animation angle = negative value
            float delta = (float) -Math.toRadians(deg * level);
            float v = base + delta;
            setRotX.invoke(b, v);
            LEDGER.put(b, new float[] {v, delta});
            long now = System.nanoTime();
            if (now - lastPrune > 30_000_000_000L) {
                lastPrune = now;
                MouthStates.prune();
            }
        } catch (Throwable t) {
            failed = true;
            TitanVoiceMod.LOGGER.warn("Mouth animation disabled (GeckoLib hook failed): {}", t.toString());
        }
    }
}
