package dev.titanvoice;

import dev.titanvoice.core.TitanKind;
import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Which titan each player is in, refreshed on the main thread a few times a second. The voice thread only
 * reads this map, so it never touches the world.
 */
public final class TitanStates {
    private TitanStates() {}

    public static final class State {
        public final TitanKind kind;
        public final boolean peeking;
        /** The titan entity. Main thread only. */
        final Entity titan;

        State(TitanKind kind, boolean peeking, Entity titan) {
            this.kind = kind;
            this.peeking = peeking;
            this.titan = titan;
        }
    }

    private static final Map<UUID, State> STATES = new ConcurrentHashMap<>();

    public static State get(UUID player) {
        return STATES.get(player);
    }

    public static void remove(UUID player) {
        STATES.remove(player);
    }

    public static void clear() {
        STATES.clear();
    }

    static void tick(MinecraftServer server) {
        if (server.getTicks() % 5 != 0 || !DaotReflect.available()) return;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            Entity titan = find(p);
            if (titan == null) {
                STATES.remove(p.getUuid());
            } else {
                STATES.put(p.getUuid(), new State(DaotReflect.kindOf(titan), DaotReflect.dismounting(titan), titan));
            }
        }
    }

    private static Entity find(ServerPlayerEntity p) {
        Entity v = p.getVehicle();
        if (v != null && DaotReflect.isShifter(v)) {
            UUID u = DaotReflect.shifterUuid(v);
            if (u == null ? v.getControllingPassenger() == p : u.equals(p.getUuid())) return v;
        }
        // peeking out of the nape: the shifter may no longer be a passenger, look for the titan nearby
        UUID id = p.getUuid();
        for (Entity e : p.getWorld().getOtherEntities(p, p.getBoundingBox().expand(16.0),
                x -> DaotReflect.isShifter(x) && id.equals(DaotReflect.shifterUuid(x)))) {
            return e;
        }
        return null;
    }
}
