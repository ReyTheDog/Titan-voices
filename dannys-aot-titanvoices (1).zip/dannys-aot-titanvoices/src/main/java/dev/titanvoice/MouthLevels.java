package dev.titanvoice;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Latest voice loudness of each speaking titan shifter. Written on the voice thread, read on the main thread. */
final class MouthLevels {
    private MouthLevels() {}

    static final class Entry {
        volatile float level;
        volatile long at;
        boolean sentSilence; // main thread only
    }

    static final Map<UUID, Entry> LEVELS = new ConcurrentHashMap<>();

    static void set(UUID id, float level) {
        Entry e = LEVELS.computeIfAbsent(id, k -> new Entry());
        e.level = level;
        e.at = System.currentTimeMillis();
        e.sentSilence = false;
    }

    static void silence(UUID id) {
        Entry e = LEVELS.get(id);
        if (e != null) e.level = 0f;
    }
}
