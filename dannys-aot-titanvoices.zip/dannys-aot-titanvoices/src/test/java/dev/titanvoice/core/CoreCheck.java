package dev.titanvoice.core;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class CoreCheck {
    static int fails = 0;

    static void check(boolean ok, String what) {
        if (!ok) { fails++; System.out.println("FAIL: " + what); }
    }

    static double freq(float[] x) {
        int zc = 0;
        for (int i = 1; i < x.length; i++) if (x[i - 1] < 0 && x[i] >= 0) zc++;
        return zc / (x.length / 48000.0);
    }

    static float[] sine(double hz, int n) {
        float[] s = new float[n];
        for (int i = 0; i < n; i++) s[i] = (float) (0.4 * Math.sin(2 * Math.PI * hz * i / 48000.0));
        return s;
    }

    public static void main(String[] a) throws Exception {
        // pitch shifter
        for (float ratio : new float[] {0.7f, 1.0f, 1.4f}) {
            PitchShifter ps = new PitchShifter(ratio, 1440);
            float[] in = sine(440, 48000), out = new float[in.length];
            for (int i = 0; i < in.length; i++) out[i] = ps.process(in[i]);
            float[] tail = java.util.Arrays.copyOfRange(out, 9600, out.length);
            double f = freq(tail);
            check(Math.abs(f - 440 * ratio) < 440 * ratio * 0.06, "pitch ratio " + ratio + " got " + f);
        }
        // distortion: bounded, not silent, changes the signal
        Distortion d = new Distortion(0.8f);
        double energy = 0; boolean bounded = true;
        for (float v : sine(300, 48000)) { float y = d.process(v); energy += y * y; if (Math.abs(y) > 1.6f) bounded = false; }
        check(bounded, "distortion bounded");
        check(energy > 1, "distortion not silent: " + energy);
        // chain: output length, loudness, clip bounds
        EffectChain c = new EffectChain(new VoiceProfile("t", 1f, 3f, 0f, 0f, 1f));
        short[] pcm = new short[960];
        for (int i = 0; i < 960; i++) pcm[i] = (short) (20000 * Math.sin(i * 0.2));
        short[] o = c.process(pcm);
        check(o.length == 960, "frame length");
        int peak = 0; for (short s : o) peak = Math.max(peak, Math.abs(s));
        check(peak <= 32767 && peak > 20000, "gain and soft clip peak " + peak);
        check(EffectChain.softClip(10f) <= 1f && EffectChain.softClip(-10f) >= -1f, "softClip bound");
        check(Math.abs(EffectChain.softClip(0.5f) - 0.5f) < 1e-6, "softClip linear");
        // kinds
        check(TitanKind.fromClassNames(List.of("daot.CartShifterTitanEntity", "daot.TestShifterTitanEntity", "daot.AttackTitanEntity")) == TitanKind.CART, "cart wins");
        check(TitanKind.fromClassNames(List.of("daot.BeastTitanEntity")) == TitanKind.BEAST, "beast");
        check(TitanKind.fromClassNames(List.of("daot.WarhammerTitanEntity")) == TitanKind.WARHAMMER, "warhammer");
        check(TitanKind.fromClassNames(List.of("daot.AttackTitanEntity")) == TitanKind.OTHER, "attack other");
        check(TitanKind.fromClassNames(List.of("java.lang.Zombie")) == TitanKind.NONE, "none");
        // decisions
        Path tmp = Files.createTempDirectory("tv").resolve("c.properties");
        VoiceConfig.load(tmp);
        check(VoiceDecision.decide(null, false).action == VoiceDecision.Action.PASS, "no titan passes");
        check(VoiceDecision.decide(TitanKind.OTHER, false).action == VoiceDecision.Action.MUTE, "other muted");
        check(VoiceDecision.decide(TitanKind.OTHER, true).action == VoiceDecision.Action.PASS, "peek unmutes");
        VoiceDecision.Result b = VoiceDecision.decide(TitanKind.BEAST, false);
        check(b.action == VoiceDecision.Action.EFFECT && b.profile.pitch < 1f && b.profile.distance > 1f, "beast deep and far");
        check(VoiceDecision.decide(TitanKind.WARHAMMER, false).profile.pitch == 1f, "warhammer normal pitch");
        check(VoiceDecision.decide(TitanKind.CART, false).profile.distortion > 0f, "cart distorted");
        // config round trip + garbage
        Files.writeString(tmp, "beast.pitch=0.5\ncart.gain=abc\nmaxDistance=99999\nenabled=false\n");
        VoiceConfig.load(tmp);
        check(VoiceConfig.beast.pitch == 0.5f, "config pitch read");
        check(VoiceConfig.cart.gain == 1.3f, "bad number falls back");
        check(VoiceConfig.maxDistance == 4096f, "clamped");
        check(VoiceDecision.decide(TitanKind.BEAST, false).action == VoiceDecision.Action.PASS, "disabled passes");
        System.out.println(fails == 0 ? "ALL CHECKS PASSED" : fails + " FAILED");
        if (fails > 0) System.exit(1);
    }
}
