package dev.titanvoice;

import dev.titanvoice.core.TitanKind;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Talks to Danny's AoT by reflection so this addon never needs it at compile time. */
final class DaotReflect {
    private DaotReflect() {}

    private static boolean tried = false;
    private static Class<?> shifterIface;
    private static Method getShifterUuid;
    private static Method isDismounting;

    static synchronized boolean available() {
        if (!tried) {
            tried = true;
            try {
                shifterIface = Class.forName("daot.ShifterTitan");
                getShifterUuid = shifterIface.getMethod("getShifterUUID");
                isDismounting = shifterIface.getMethod("isDismounting");
            } catch (Throwable t) {
                shifterIface = null;
                TitanVoiceMod.LOGGER.info("Danny's AoT not found (daot.ShifterTitan missing); no voice effects will be applied.");
            }
        }
        return shifterIface != null;
    }

    static boolean isShifter(Object e) {
        return available() && shifterIface.isInstance(e);
    }

    static UUID shifterUuid(Object titan) {
        try {
            Object o = getShifterUuid.invoke(titan);
            return o instanceof UUID ? (UUID) o : null;
        } catch (Throwable t) {
            return null;
        }
    }

    static boolean dismounting(Object titan) {
        try {
            return Boolean.TRUE.equals(isDismounting.invoke(titan));
        } catch (Throwable t) {
            return false;
        }
    }

    static TitanKind kindOf(Object titan) {
        List<String> names = new ArrayList<>();
        for (Class<?> c = titan.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            names.add(c.getName());
        }
        TitanKind k = TitanKind.fromClassNames(names);
        // any shifter titan we do not know by name still cannot speak
        return k == TitanKind.NONE ? TitanKind.OTHER : k;
    }
}
