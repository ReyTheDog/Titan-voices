package dev.titanvoice.core;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Simple properties-file config. Missing keys fall back to defaults and are written back. */
public final class VoiceConfig {
    private VoiceConfig() {}

    public static boolean enabled = true;
    /** Attack, Armored, Colossal, Female, Jaw and Ogre titans cannot speak: the player is muted. */
    public static boolean muteOtherTitans = true;
    /** While the shifter is out of the nape (dismounted) the voice is normal again. */
    public static boolean peekRestoresVoice = true;
    /** Whispering is quieter: its range is this fraction of the speaking range. */
    public static float whisperFactor = 0.5f;
    /** No voice carries farther than this many blocks, whatever the multipliers say. */
    public static float maxDistance = 512f;
    public static boolean debug = false;

    public static VoiceProfile beast = new VoiceProfile("beast", 0.70f, 1.8f, 0.6f, 0f, 3.0f, 0f, 0.35f);
    public static VoiceProfile warhammer = new VoiceProfile("warhammer", 1.0f, 1.8f, 0.25f, 0f, 3.0f, 0f, 0.85f);
    public static VoiceProfile cart = new VoiceProfile("cart", 0.85f, 1.4f, 0f, 1.0f, 1.5f, 0.55f, 0f);

    public static void load(Path file) {
        Properties p = new Properties();
        if (Files.isRegularFile(file)) {
            try (Reader r = Files.newBufferedReader(file)) {
                p.load(r);
            } catch (IOException ignored) {
                // defaults
            }
        }
        enabled = bool(p, "enabled", enabled);
        muteOtherTitans = bool(p, "muteOtherTitans", muteOtherTitans);
        peekRestoresVoice = bool(p, "peekRestoresVoice", peekRestoresVoice);
        whisperFactor = clamp(num(p, "whisperFactor", whisperFactor), 0.05f, 1f);
        maxDistance = clamp(num(p, "maxDistance", maxDistance), 8f, 4096f);
        debug = bool(p, "debug", debug);
        beast = profile(p, "beast", beast);
        warhammer = profile(p, "warhammer", warhammer);
        cart = profile(p, "cart", cart);
        write(file);
    }

    public static VoiceProfile profileFor(TitanKind kind) {
        switch (kind) {
            case BEAST: return beast;
            case WARHAMMER: return warhammer;
            case CART: return cart;
            default: return null;
        }
    }

    private static VoiceProfile profile(Properties p, String key, VoiceProfile d) {
        return new VoiceProfile(d.name,
                clamp(num(p, key + ".pitch", d.pitch), 0.4f, 2.0f),
                clamp(num(p, key + ".gain", d.gain), 0.1f, 5f),
                clamp(num(p, key + ".bass", d.bass), 0f, 2f),
                clamp(num(p, key + ".distortion", d.distortion), 0f, 1f),
                clamp(num(p, key + ".distance", d.distance), 0.2f, 20f),
                clamp(num(p, key + ".ringMod", d.ringMod), 0f, 1f),
                clamp(num(p, key + ".reverb", d.reverb), 0f, 1f));
    }

    private static void write(Path file) {
        StringBuilder s = new StringBuilder();
        s.append("# Danny's AoT - Titan Voices config (server side: this is read where Simple Voice Chat runs)\n");
        s.append("enabled=").append(enabled).append("\n");
        s.append("# Attack, Armored, Colossal, Female, Jaw and Ogre titans cannot speak: the player is muted\n");
        s.append("muteOtherTitans=").append(muteOtherTitans).append("\n");
        s.append("# While the shifter is out of the nape the voice is normal again\n");
        s.append("peekRestoresVoice=").append(peekRestoresVoice).append("\n");
        s.append("# Whispering carries this fraction of the normal range\n");
        s.append("whisperFactor=").append(whisperFactor).append("\n");
        s.append("# No voice carries farther than this many blocks\n");
        s.append("maxDistance=").append(maxDistance).append("\n");
        s.append("# Logs which effect each speaker gets\n");
        s.append("debug=").append(debug).append("\n");
        s.append("# Per titan: pitch (1 = normal, lower = deeper), gain (loudness), bass (0..2),\n");
        s.append("# distortion (0..1), distance (times the normal voice chat range),\n# ringMod (0..1, robotic), reverb (0..1, echo and room)\n");
        for (VoiceProfile v : new VoiceProfile[] {beast, warhammer, cart}) {
            s.append(v.name).append(".pitch=").append(v.pitch).append("\n");
            s.append(v.name).append(".gain=").append(v.gain).append("\n");
            s.append(v.name).append(".bass=").append(v.bass).append("\n");
            s.append(v.name).append(".distortion=").append(v.distortion).append("\n");
            s.append(v.name).append(".distance=").append(v.distance).append("\n");
            s.append(v.name).append(".ringMod=").append(v.ringMod).append("\n");
            s.append(v.name).append(".reverb=").append(v.reverb).append("\n");
        }
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, s.toString());
        } catch (IOException ignored) {
            // read-only config dir is fine
        }
    }

    private static boolean bool(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v.trim());
    }

    private static float num(Properties p, String key, float def) {
        String v = p.getProperty(key);
        if (v == null) return def;
        try {
            return Float.parseFloat(v.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
