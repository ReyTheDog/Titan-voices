package dev.titanvoice.core;

/**
 * Streaming pitch shifter for voice: two read heads sweep through a delay line and are cross-faded, so the
 * pitch changes without the voice getting slower or faster. Constant latency of about one window, one output
 * sample per input sample (so a 20 ms voice frame in is a 20 ms frame out).
 */
public final class PitchShifter {
    private final float[] buf;
    private final int mask;
    private final float window;
    private final float step;
    private int write = 0;
    private float phase = 0f;

    /** @param ratio 1 = unchanged, 0.7 = about 6 semitones lower, 1.5 = a fifth higher */
    public PitchShifter(float ratio, int windowSamples) {
        int size = 1;
        while (size < windowSamples * 2 + 8) size <<= 1;
        this.buf = new float[size];
        this.mask = size - 1;
        this.window = windowSamples;
        this.step = (1f - ratio) / windowSamples;
    }

    public float process(float x) {
        buf[write] = x;
        float dA = phase * window;
        float dB = ((phase + 0.5f) % 1f) * window;
        float gA = 1f - Math.abs(2f * phase - 1f);
        float pB = (phase + 0.5f) % 1f;
        float gB = 1f - Math.abs(2f * pB - 1f);
        float y = read(write - dA) * gA + read(write - dB) * gB;
        phase += step;
        if (phase >= 1f) phase -= 1f;
        else if (phase < 0f) phase += 1f;
        write = (write + 1) & mask;
        return y;
    }

    private float read(float pos) {
        int i0 = (int) Math.floor(pos);
        float f = pos - i0;
        float a = buf[i0 & mask];
        float b = buf[(i0 + 1) & mask];
        return a + (b - a) * f;
    }

    public void reset() {
        java.util.Arrays.fill(buf, 0f);
        write = 0;
        phase = 0f;
    }
}
