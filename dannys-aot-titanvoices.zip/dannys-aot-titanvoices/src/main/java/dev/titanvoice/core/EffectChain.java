package dev.titanvoice.core;

/** The voice effects of one speaker: pitch, distortion, bass, loudness. One instance per speaking player. */
public final class EffectChain {
    private static final int WINDOW = 1440; // 30 ms at 48 kHz
    private static final float BASS_A = 1f - (float) Math.exp(-2.0 * Math.PI * 250.0 / 48000.0);

    private final VoiceProfile profile;
    private final PitchShifter shifter;
    private final Distortion distortion;
    private float bassLp = 0f;

    public EffectChain(VoiceProfile profile) {
        this.profile = profile;
        this.shifter = profile.needsPitchShift() ? new PitchShifter(profile.pitch, WINDOW) : null;
        this.distortion = profile.distortion > 0.001f ? new Distortion(profile.distortion) : null;
    }

    public VoiceProfile profile() {
        return profile;
    }

    /** Processes a frame of 16-bit mono PCM and returns a new array of the same length. */
    public short[] process(short[] pcm) {
        short[] out = new short[pcm.length];
        for (int i = 0; i < pcm.length; i++) {
            float x = pcm[i] / 32768f;
            if (shifter != null) x = shifter.process(x);
            if (distortion != null) x = distortion.process(x);
            if (profile.bass > 0f) {
                bassLp += BASS_A * (x - bassLp);
                x += profile.bass * bassLp;
            }
            x = softClip(x * profile.gain);
            int v = Math.round(x * 32767f);
            out[i] = (short) Math.max(-32768, Math.min(32767, v));
        }
        return out;
    }

    /** Clean up after a pause in speaking so nothing of the last words rings on. */
    public void reset() {
        if (shifter != null) shifter.reset();
        if (distortion != null) distortion.reset();
        bassLp = 0f;
    }

    /** Linear up to 0.7, then smoothly bends towards (never reaching) 1. */
    static float softClip(float x) {
        float a = Math.abs(x);
        if (a <= 0.7f) return x;
        float y = 0.7f + 0.3f * (float) Math.tanh((a - 0.7f) / 0.3f);
        return x < 0f ? -y : y;
    }
}
