package dev.titanvoice.core;

/**
 * Radio-like robotic distortion (the Cart Titan's voice): low sample rate, few bits, hard drive and a narrow
 * telephone-like band. {@code amount} 0..1 sets how harsh it is.
 */
public final class Distortion {
    private final int hold;
    private final float levels;
    private final float drive;
    private final float lpA;
    private final float hpA;
    private int counter = 0;
    private float held = 0f;
    private float lp = 0f;
    private float hp = 0f;

    public Distortion(float amount) {
        float a = Math.max(0f, Math.min(1f, amount));
        this.hold = 1 + Math.round(a * 4f);               // 48 kHz down to ~10 kHz
        this.levels = 128f - a * 108f;                    // ~8 bits down to ~4.3 bits
        this.drive = 1f + a * 5f;
        this.lpA = 1f - (float) Math.exp(-2.0 * Math.PI * (7000.0 - a * 3800.0) / 48000.0); // 7 kHz .. 3.2 kHz
        this.hpA = 1f - (float) Math.exp(-2.0 * Math.PI * (60.0 + a * 240.0) / 48000.0);     // 60 Hz .. 300 Hz
    }

    public float process(float x) {
        if (counter++ % hold == 0) held = x;
        float y = Math.round(held * levels) / levels;
        y = (float) Math.tanh(y * drive);
        lp += lpA * (y - lp);
        hp += hpA * (lp - hp);
        return (lp - hp) * 1.3f;
    }

    public void reset() {
        counter = 0;
        held = lp = hp = 0f;
    }
}
