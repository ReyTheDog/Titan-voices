package dev.titanvoice.core;

/** Which kind of Danny's AoT shifter titan a player is in. */
public enum TitanKind {
    /** Not in a titan (or not one of the shifter titans). */
    NONE,
    BEAST,
    WARHAMMER,
    CART,
    /** Every other shifter titan (Attack, Armored, Colossal, Female, Jaw, Ogre): cannot speak. */
    OTHER;

    /**
     * Works out the kind from the class name of the titan entity and all its parents (the Cart and Jaw
     * titans extend the Attack titan, so the most specific name must win).
     */
    public static TitanKind fromClassNames(Iterable<String> classNames) {
        boolean shifter = false;
        for (String n : classNames) {
            if (n.equals("daot.CartShifterTitanEntity")) return CART;
            if (n.equals("daot.BeastTitanEntity")) return BEAST;
            if (n.equals("daot.WarhammerTitanEntity")) return WARHAMMER;
            if (n.equals("daot.AttackTitanEntity") || n.equals("daot.ArmoredTitanEntity")
                    || n.equals("daot.ColossalTitanEntity") || n.equals("daot.FemaleTitanEntity")
                    || n.equals("daot.TestShifterTitanEntity") || n.equals("daot.OgreShifterTitanEntity")) {
                shifter = true;
            }
        }
        return shifter ? OTHER : NONE;
    }
}
