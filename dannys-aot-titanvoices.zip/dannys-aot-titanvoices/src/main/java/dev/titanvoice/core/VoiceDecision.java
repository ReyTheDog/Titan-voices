package dev.titanvoice.core;

/** Decides what happens to a player's voice given the titan they are in. */
public final class VoiceDecision {
    private VoiceDecision() {}

    public enum Action {
        /** Leave the voice to Simple Voice Chat, untouched. */
        PASS,
        /** The voice is dropped. */
        MUTE,
        /** The voice goes through the profile's effects. */
        EFFECT
    }

    public static final class Result {
        public final Action action;
        public final VoiceProfile profile;

        Result(Action action, VoiceProfile profile) {
            this.action = action;
            this.profile = profile;
        }
    }

    private static final Result PASS = new Result(Action.PASS, null);
    private static final Result MUTE = new Result(Action.MUTE, null);

    /** @param peeking the shifter is out of the nape (dismounted) */
    public static Result decide(TitanKind kind, boolean peeking) {
        if (!VoiceConfig.enabled || kind == null || kind == TitanKind.NONE) return PASS;
        if (peeking && VoiceConfig.peekRestoresVoice) return PASS;
        if (kind == TitanKind.OTHER) return VoiceConfig.muteOtherTitans ? MUTE : PASS;
        VoiceProfile p = VoiceConfig.profileFor(kind);
        return p == null ? PASS : new Result(Action.EFFECT, p);
    }
}
