package dev.titanvoice;

import dev.titanvoice.core.VoiceConfig;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TitanVoiceMod implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("dannys-aot-titanvoices");

    @Override
    public void onInitialize() {
        VoiceConfig.load(FabricLoader.getInstance().getConfigDir().resolve("dannys-aot-titanvoices.properties"));
        ServerTickEvents.END_SERVER_TICK.register(TitanStates::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            TitanStates.remove(handler.getPlayer().getUuid());
            TitanVoicePlugin.forget(handler.getPlayer().getUuid());
        });
        LOGGER.info("Titan Voices loaded");
    }
}
